var cur_org = "AICTE";
var cur_yr = "2000-2001";
$(document).ready(function () {
  $(".org").text(cur_org);
  $(".h_year").text(cur_yr);

  div = $(".menu_type");
  div1 = $(".menu_year");
  years = [
    "2000-2001",
    "2001-2002",
    "2002-2003",
    "2003-2004",
    "2004-2005",
    "2005-2006",
    "2006-2007",
    "2007-2008",
    "2008-2009",
    "2009-2010",
    "2010-2011",
    "2011-2012",
    "2012-2013",
    "2013-2014",
    "2014-2015",
    "2015-2016",
    "2016-2017",
    "2017-2018",
    "2018-2019",
  ];
  keys = [
    "AICTE",
    "CSIR",
    "DAE",
    "DBT",
    "DoC",
    "DOD",
    "DOSHE",
    "DRDO",
    "DSIR",
    "DST",
    "ICAR",
    "ICMR",
    "ISRO",
    "MNCES",
    "MoCIT",
    "MoEF",
    "MoSJE",
    "MoWR",
    "UGC",
    "MFPI",
    "AYUSH",
    "MoP",
    "PCRA",
    "CIL",
    "MNRE",
    "MoS",
    "MoES",
    "MEITY",
    "MoEFCC",
  ];
  for (var i = 0; i < keys.length; i++) {
    div.append(
      `<div class="dropdown-item" onclick="change_org('${keys[i]}')">${keys[i]}</div>`
    );
  }
  for (var i = 0; i < years.length; i++) {
    div1.append(
      `<div class="dropdown-item" onclick="change_year('${years[i]}')">${years[i]}</div>`
    );
  }
  window.onclick = function (event) {
    if (!event.target.matches(".dropbtn")) {
      var dropdowns = document.getElementsByClassName("dropdown-content");
      var i;
      for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        if (openDropdown.classList.contains("show")) {
          openDropdown.classList.remove("show");
        }
      }
    }
  };
});

function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}
function change_org(org) {
  cur_org = org;
  $(".org").text(org);
  fetch("data/data.json")
    .then((Response) => Response.json())
    .then((data) => {
      rows = data[org];
      div = $(".table tbody");
      k = Object.keys(rows[0]);
      //console.log(k);
      div.empty();
      for (var i = 0; i < rows.length; i++) {
        // console.log(rows[i]["Year "],cur_yr)

        if (rows[i]["Year "] == cur_yr) {
          //console.log(rows[i]);

          div.append(`<tr>
                    <td>${rows[i][k[0]]}</td>
                    <td>${rows[i][k[1]]}</td>
                    <td>${rows[i][k[2]]}</td>
                    <td>${rows[i][k[3]]}</td>
                    <td>${rows[i][k[4]]}</td>
                    <td>${rows[i][k[5]]}</td>
                    <td>${rows[i][k[6]]}</td>
                    <td>${rows[i][k[7]]}</td>
                    <td>${rows[i][k[8]]}</td>
                  </tr>`);
        }
      }
      // console.log(rows[0]["Year "])
    });
}
function change_year(yr) {
  cur_yr = yr;
  $(".h_year").text(yr);
  fetch("data/data.json")
    .then((Response) => Response.json())
    .then((data) => {
      rows = data[cur_org];
      div = $(".table tbody");
      k = Object.keys(rows[0]);
      //console.log(k)
      div.empty();
      for (var i = 0; i < rows.length; i++) {
        // console.log(rows[i]["Year "],cur_yr)

        if (rows[i]["Year "] == cur_yr) {
          //console.log(rows[i])

          div.append(`<tr>
                    <td>${rows[i][k[0]]}</td>
                    <td>${rows[i][k[1]]}</td>
                    <td>${rows[i][k[2]]}</td>
                    <td>${rows[i][k[3]]}</td>
                    <td>${rows[i][k[4]]}</td>
                    <td>${rows[i][k[5]]}</td>
                    <td>${rows[i][k[6]]}</td>
                    <td>${rows[i][k[7]]}</td>
                    <td>${rows[i][k[8]]}</td>
                  </tr>`);
        }
      }
      // console.log(rows[0]["Year "])
    });
}
